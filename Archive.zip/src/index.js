// Import all plugins
import * as bootstrap from 'bootstrap';





// var rtlcss = require('rtlcss');
// var result = rtlcss.process("body { direction:ltr; }");
// //result == body { direction:rtl; }



